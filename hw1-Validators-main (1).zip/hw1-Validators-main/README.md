# homework1-Validators
The starter code for SI339/SI539 homework1.  You do not need to edit or write any code  in this assignment!  

Instead, download the code and check personal.html via:
- W3
- Wave 
- aXe
- the console

Take a screenshot - **including the URL where applicable ** of the page with the errors visible. 
